package com.example.realnoamozproject;

public class User
{
    public String Name;
    public String Age;
    public String Gender;
    public String Password;

    public User()
    {

    }
    public User(String name, String gener, String age, String password)
    {
        this.Name = name;
        this.Age = age;
        this.Gender = gener;
        this.Password = password;
    }

    public void setPassword(String password)
    {
        Password = password;
    }
    public void setName(String name)
    {
        Name = name;
    }
    public void setAge(String age)
    {
        Age = age;
    }
    public void setGender(String gender)
    {
        Gender = gender;
    }
    @Override
    public String toString()
    {
        return ("Name: " + Name + ", Password: " + Password + ", Gender: " + Gender + ", Age: " + Age);
    }
}
